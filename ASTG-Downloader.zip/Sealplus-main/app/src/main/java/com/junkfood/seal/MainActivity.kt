package com.junkfood.seal

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.junkfood.seal.ui.common.LocalDarkTheme
import com.junkfood.seal.ui.common.SettingsProvider
import com.junkfood.seal.ui.common.ThemedToastHost
import com.junkfood.seal.ui.page.AppEntry
import com.junkfood.seal.ui.page.downloadv2.configure.DownloadDialogViewModel
import com.junkfood.seal.ui.page.onboarding.OnboardingScreen
import com.junkfood.seal.ui.page.security.LockScreen
import com.junkfood.seal.ui.page.splash.SplashScreen
import com.junkfood.seal.ui.theme.SealTheme
import com.junkfood.seal.util.AuthenticationManager
import com.junkfood.seal.util.ONBOARDING_COMPLETED
import com.junkfood.seal.util.PreferenceUtil
import com.junkfood.seal.util.PreferenceUtil.getBoolean
import com.junkfood.seal.util.PreferenceUtil.updateBoolean
import com.junkfood.seal.util.matchUrlFromSharedText
import com.junkfood.seal.util.setLanguage
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.compose.KoinContext

class MainActivity : AppCompatActivity() {
    private val dialogViewModel: DownloadDialogViewModel by viewModel()
    private var isAppInBackground = false

    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT < 33) {
            lifecycleScope.launch(Dispatchers.IO) {
                setLanguage(PreferenceUtil.getLocaleFromPreference())
            }
        }
        enableEdgeToEdge()

        // Handle shared URL from intent on cold launch
        intent.getSharedURL()?.let { url ->
            dialogViewModel.setSharedUrl(url)
        }
        
        setContent {
            KoinContext {
                val windowSizeClass = calculateWindowSizeClass(this)
                var showSplash by remember { mutableStateOf(true) }
                var showOnboarding by remember { mutableStateOf(!ONBOARDING_COMPLETED.getBoolean()) }
                var isLocked by remember { mutableStateOf(false) }
                LaunchedEffect(showOnboarding) {
                    if (!showOnboarding) {
                        isLocked = AuthenticationManager.isSecurityEnabled() &&
                                AuthenticationManager.isAuthenticationNeeded()
                    }
                }
                
                SettingsProvider(windowWidthSizeClass = windowSizeClass.widthSizeClass) {
                    SealTheme(
                        darkTheme = LocalDarkTheme.current.isDarkTheme(),
                        isHighContrastModeEnabled = LocalDarkTheme.current.isHighContrastModeEnabled,
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            when {
                                showSplash -> {
                                    SplashScreen(
                                        onSplashFinished = {
                                            showSplash = false
                                        }
                                    )
                                }
                                showOnboarding -> {
                                    OnboardingScreen(
                                        onFinish = {
                                            ONBOARDING_COMPLETED.updateBoolean(true)
                                            showOnboarding = false
                                        }
                                    )
                                }
                                else -> {
                                    AppEntry(dialogViewModel = dialogViewModel)
                                    
                                    // Show lock screen overlay if locked
                                    if (isLocked) {
                                        LockScreen(
                                            onUnlocked = {
                                                isLocked = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Themed toast overlay – always on top
                            ThemedToastHost()
                        }
                    }
                }
            }
        }
    }
    
    override fun onPause() {
        super.onPause()
        isAppInBackground = true
    }
    
    override fun onResume() {
        super.onResume()
        val wasInBackground = isAppInBackground
        isAppInBackground = false
        if (wasInBackground && AuthenticationManager.isSecurityEnabled() && 
            AuthenticationManager.isAuthenticationNeeded()) {
            // Trigger re-authentication by recreating activity
            recreate()
            return
        }
        // If a download's foreground-service promotion was blocked earlier while the app was
        // backgrounded without a battery-optimization exemption (see DownloadService), the app
        // being visible now satisfies Android's visible-app exemption — retry immediately so
        // the download notification/foreground status catches up without waiting on the next
        // task-state change.
        App.retryForegroundPromotionIfNeeded()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val url = intent.getSharedURL()
        if (url != null) {
            dialogViewModel.setSharedUrl(url)
        }
    }

    private fun Intent.getSharedURL(): String? {
        val intent = this

        return when (intent.action) {
            Intent.ACTION_VIEW -> {
                intent.dataString
            }

            Intent.ACTION_SEND -> {
                intent.getStringExtra(Intent.EXTRA_TEXT)?.let { sharedContent ->
                    intent.removeExtra(Intent.EXTRA_TEXT)
                    matchUrlFromSharedText(sharedContent).also { matchedUrl ->
                        if (sharedUrlCached != matchedUrl) {
                            sharedUrlCached = matchedUrl
                        }
                    }
                }
            }

            else -> {
                null
            }
        }
    }

    companion object {
        private const val TAG = "MainActivity"
        private var sharedUrlCached = ""
    }
}
