# ASTG Downloader

Developed and maintained by **ASTG**.

This app is a modified version of **Seal** (by JunkFood02 and contributors)
and **Seal Plus** (by Mahesh Technicals), both licensed under the
GNU General Public License v3.0. Original copyright notices and the
LICENSE file are kept intact, and this project's source remains available
under GPL-3.0. Powered by yt-dlp (Unlicense).
